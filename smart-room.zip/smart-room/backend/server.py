"""Backend Smart Room.

Cầu nối: ESP32 (TCP, lệnh text) <-> trình duyệt (WebSocket, JSON). Lưu lịch sử vào SQLite.
Chạy:  python server.py --esp 192.168.50.2:3333      (mở http://localhost:8000)
Thử không cần board:  python mock_esp32.py   rồi   python server.py --esp 127.0.0.1:3333
"""
import argparse
import asyncio
import json
import sqlite3
import time
import unicodedata
from collections import deque
from contextlib import asynccontextmanager
from pathlib import Path

import uvicorn
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse, JSONResponse

BASE = Path(__file__).parent
CFG = {"host": "192.168.50.2", "port": 3333, "db": str(BASE / "smartroom.db")}

db: sqlite3.Connection
clients: set[WebSocket] = set()
pending: deque[str] = deque()        # lệnh đã gửi, đang chờ OK/ERR (ESP32 trả lời theo thứ tự)
link = {"writer": None}              # kết nối TCP hiện tại tới ESP32
state = {"connected": False, "l1": 0, "l2": 0, "fan": 0, "th": 2000, "alm": 0}

SIMPLE_CMDS = {"L1_ON", "L1_OFF", "L2_ON", "L2_OFF", "FAN_ON", "FAN_OFF", "GET_STATUS"}


# ---------- tiện ích ----------
def to_ascii(text: str) -> str:
    """LCD không hiển thị dấu tiếng Việt: bỏ dấu, chỉ giữ ký tự in được."""
    text = text.replace("đ", "d").replace("Đ", "D")
    text = unicodedata.normalize("NFKD", text)
    return "".join(c for c in text if 32 <= ord(c) < 127)


def parse_kv(s: str) -> dict:
    out = {}
    for part in s.split(","):
        if "=" in part:
            k, v = part.split("=", 1)
            out[k.strip().upper()] = v.strip()
    return out


def build_line(msg: dict):
    """Chuyển lệnh JSON từ trình duyệt thành dòng gửi ESP32. Trả (tên lệnh, dòng) hoặc None."""
    cmd = str(msg.get("cmd", "")).upper()
    if cmd in SIMPLE_CMDS:
        return cmd, cmd
    if cmd == "MSG":
        text = to_ascii(str(msg.get("text", ""))).strip()[:32]
        return (cmd, "MSG:" + text) if text else None
    if cmd == "SET_GAS_TH":
        try:
            v = int(msg.get("value"))
        except (TypeError, ValueError):
            return None
        return (cmd, f"SET_GAS_TH:{v}") if 0 <= v <= 4095 else None
    return None


async def broadcast(msg: dict):
    data = json.dumps(msg)
    for ws in list(clients):
        try:
            await ws.send_text(data)
        except Exception:
            clients.discard(ws)


def history(minutes: float, limit: int = 3000):
    rows = db.execute(
        "SELECT ts, temp, hum, gas FROM readings WHERE ts > ? ORDER BY ts DESC LIMIT ?",
        (time.time() - minutes * 60, limit),
    ).fetchall()
    return [{"ts": r[0], "t": r[1], "h": r[2], "gas": r[3]} for r in reversed(rows)]


def recent_alarms(n: int = 20):
    rows = db.execute("SELECT ts, active, val FROM alarms ORDER BY ts DESC LIMIT ?", (n,)).fetchall()
    return [{"ts": r[0], "active": bool(r[1]), "val": r[2]} for r in reversed(rows)]


def snapshot() -> dict:
    return {"type": "snapshot", "connected": state["connected"],
            "state": {k: state[k] for k in ("l1", "l2", "fan", "th", "alm")},
            "history": history(60), "alarms": recent_alarms()}


# ---------- xử lý dòng từ ESP32 ----------
async def handle_line(line: str):
    line = line.strip()
    if not line:
        return
    head, _, rest = line.partition(":")
    head = head.upper()
    now = time.time()
    try:
        if head == "DATA":
            kv = parse_kv(rest)
            t, h, gas = float(kv["T"]), float(kv["H"]), int(float(kv["GAS"]))
            db.execute("INSERT INTO readings VALUES (?,?,?,?)", (now, t, h, gas))
            db.commit()
            await broadcast({"type": "data", "ts": now, "t": t, "h": h, "gas": gas})
        elif head == "STATE":
            kv = parse_kv(rest)
            state.update(l1=int(kv["L1"]), l2=int(kv["L2"]), fan=int(kv["FAN"]),
                         th=int(kv["TH"]), alm=int(kv["ALM"]))
            await broadcast({"type": "state", **{k: state[k] for k in ("l1", "l2", "fan", "th", "alm")}})
        elif head == "ALARM":
            kv = parse_kv(rest)
            active, val = kv.get("GAS") == "1", int(kv.get("VAL", 0))
            state["alm"] = int(active)
            db.execute("INSERT INTO alarms VALUES (?,?,?)", (now, int(active), val))
            db.commit()
            await broadcast({"type": "alarm", "ts": now, "active": active, "val": val})
        elif head in ("OK", "ERR"):
            cmd = pending.popleft() if pending else "?"
            await broadcast({"type": "ack", "cmd": cmd, "ok": head == "OK", "detail": rest})
    except (KeyError, ValueError):
        pass   # dòng sai định dạng: bỏ qua


async def set_connected(up: bool):
    if state["connected"] != up:
        state["connected"] = up
        await broadcast({"type": "link", "connected": up})


async def esp_link():
    """Giữ kết nối TCP tới ESP32, tự nối lại khi mất."""
    wait = 1
    while True:
        try:
            reader, writer = await asyncio.wait_for(
                asyncio.open_connection(CFG["host"], CFG["port"]), timeout=3)
        except (OSError, asyncio.TimeoutError):
            await set_connected(False)
            await asyncio.sleep(wait)
            wait = min(wait + 1, 5)
            continue
        wait = 1
        link["writer"] = writer
        pending.clear()
        await set_connected(True)
        try:
            while True:
                raw = await asyncio.wait_for(reader.readline(), timeout=8)   # DATA đến mỗi 2 s
                if not raw:
                    break
                await handle_line(raw.decode("ascii", "ignore"))
        except (OSError, asyncio.TimeoutError):
            pass
        finally:
            link["writer"] = None
            writer.close()
            await set_connected(False)


async def send_to_esp(name: str, line: str):
    w = link["writer"]
    if w is None:
        await broadcast({"type": "ack", "cmd": name, "ok": False, "detail": "ESP32 chưa kết nối"})
        return
    if name != "GET_STATUS":          # GET_STATUS được trả lời bằng STATE, không phải OK
        pending.append(name)
    try:
        w.write((line + "\n").encode("ascii"))
        await w.drain()
    except OSError:
        await broadcast({"type": "ack", "cmd": name, "ok": False, "detail": "Gửi lệnh thất bại"})


# ---------- web ----------
@asynccontextmanager
async def lifespan(app: FastAPI):
    global db
    db = sqlite3.connect(CFG["db"], check_same_thread=False)
    db.executescript("""
        CREATE TABLE IF NOT EXISTS readings (ts REAL, temp REAL, hum REAL, gas INTEGER);
        CREATE INDEX IF NOT EXISTS idx_readings_ts ON readings (ts);
        CREATE TABLE IF NOT EXISTS alarms (ts REAL, active INTEGER, val INTEGER);
    """)
    task = asyncio.create_task(esp_link())
    yield
    task.cancel()
    db.close()


app = FastAPI(lifespan=lifespan)


@app.get("/")
async def index():
    return FileResponse(BASE / "static" / "index.html")


@app.get("/api/history")
async def api_history(minutes: float = 30):
    return JSONResponse(history(min(max(minutes, 1), 1440)))


@app.get("/api/alarms")
async def api_alarms():
    return JSONResponse(recent_alarms(100))


@app.websocket("/ws")
async def ws_endpoint(ws: WebSocket):
    await ws.accept()
    clients.add(ws)
    try:
        await ws.send_text(json.dumps(snapshot()))
        while True:
            try:
                msg = json.loads(await ws.receive_text())
            except ValueError:
                continue
            built = build_line(msg) if isinstance(msg, dict) else None
            if built is None:
                await ws.send_text(json.dumps({"type": "ack", "cmd": str(msg.get("cmd", "?")) if isinstance(msg, dict) else "?",
                                               "ok": False, "detail": "Lệnh không hợp lệ"}))
                continue
            await send_to_esp(*built)
    except WebSocketDisconnect:
        pass
    finally:
        clients.discard(ws)


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="Backend Smart Room")
    ap.add_argument("--esp", default="192.168.50.2:3333", help="địa chỉ ESP32, dạng host:port")
    ap.add_argument("--port", type=int, default=8000, help="cổng web của dashboard")
    ap.add_argument("--db", default=CFG["db"], help="file SQLite")
    a = ap.parse_args()
    host, _, port = a.esp.partition(":")
    CFG.update(host=host, port=int(port or 3333), db=a.db)
    print(f"Dashboard: http://localhost:{a.port}   ESP32: {CFG['host']}:{CFG['port']}   DB: {CFG['db']}")
    uvicorn.run(app, host="0.0.0.0", port=a.port, log_level="warning")
