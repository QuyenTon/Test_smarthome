"""ESP32 giả lập: nói đúng giao thức trong PROTOCOL.md để thử backend/dashboard khi chưa có board.

Chạy:  python mock_esp32.py              (nghe cổng 3333)
Trong lúc chạy, gõ vào cửa sổ này:
    gas 2500      ép giá trị khí gas (để thử báo động)
    gas auto      trở lại dao động tự động (chu kỳ 90 s)
"""
import asyncio
import math
import random
import sys
import time

PORT = 3333
S = {"l1": 0, "l2": 0, "fan": 0, "th": 2000, "alm": 0}
forced_gas = None
writers: set = set()
CMDS = {"L1_ON": ("l1", 1), "L1_OFF": ("l1", 0), "L2_ON": ("l2", 1),
        "L2_OFF": ("l2", 0), "FAN_ON": ("fan", 1), "FAN_OFF": ("fan", 0)}


def state_line() -> str:
    return f"STATE:L1={S['l1']},L2={S['l2']},FAN={S['fan']},TH={S['th']},ALM={S['alm']}\n"


def handle(line: str) -> str:
    line = line.strip()
    if not line:
        return ""
    head, _, arg = line.partition(":")
    head = head.strip().upper()
    if head in CMDS:
        k, v = CMDS[head]
        S[k] = v
        return "OK\n" + state_line()
    if head == "MSG":
        arg = arg.lstrip()
        if not arg:
            return "ERR:EMPTY\n"
        if len(arg) > 32:
            return "ERR:TOO_LONG\n"
        print(f"  [LCD] {arg}")
        return "OK\n"
    if head == "SET_GAS_TH":
        try:
            v = int(arg)
        except ValueError:
            return "ERR:BAD_VALUE\n"
        if not 0 <= v <= 4095:
            return "ERR:BAD_VALUE\n"
        S["th"] = v
        return "OK\n" + state_line()
    if head == "GET_STATUS":
        return state_line()
    if head == "PING":
        return "PONG\n"
    return "ERR:UNKNOWN_CMD\n"


def sample():
    s = time.time()
    t = 28 + 2 * math.sin(s / 40) + random.uniform(-0.25, 0.25)
    h = 65 + 5 * math.sin(s / 55) + random.uniform(-0.5, 0.5)
    gas = forced_gas if forced_gas is not None else \
        int(1400 + 1300 * math.sin(s * 2 * math.pi / 90) + random.randint(-20, 20))
    return t, h, gas


def send_all(text: str):
    for w in list(writers):
        try:
            w.write(text.encode())
        except Exception:
            writers.discard(w)


async def ticker():
    while True:
        await asyncio.sleep(2)
        t, h, gas = sample()
        send_all(f"DATA:T={t:.1f},H={h:.1f},GAS={gas}\n")
        now = S["alm"]
        if not now and gas >= S["th"]:
            now = 1
        elif now and gas < S["th"] - S["th"] // 10:
            now = 0
        if now != S["alm"]:
            S["alm"] = now
            print(f"  [ALARM] {'BAT' if now else 'TAT'} (gas={gas})")
            send_all(f"ALARM:GAS={now},VAL={gas}\n")


async def client(reader, writer):
    print("client ket noi:", writer.get_extra_info("peername"))
    writers.add(writer)
    writer.write(state_line().encode())
    try:
        while True:
            raw = await reader.readline()
            if not raw:
                break
            text = raw.decode("ascii", "ignore")
            reply = handle(text)
            print(f"  <- {text.strip():<24} -> {reply.strip().splitlines()[0] if reply else ''}")
            if reply:
                writer.write(reply.encode())
    except ConnectionError:
        pass
    finally:
        writers.discard(writer)
        writer.close()
        print("client da ngat")


async def console():
    global forced_gas
    loop = asyncio.get_running_loop()
    while True:
        line = await loop.run_in_executor(None, sys.stdin.readline)
        if not line:
            return
        parts = line.split()
        if len(parts) == 2 and parts[0] == "gas":
            forced_gas = None if parts[1] == "auto" else int(parts[1]) if parts[1].isdigit() else forced_gas
            print("  gas:", "tu dong" if forced_gas is None else forced_gas)


async def main():
    server = await asyncio.start_server(client, "0.0.0.0", PORT)
    print(f"ESP32 gia lap dang nghe cong {PORT}. Go 'gas 2500' de thu bao dong, 'gas auto' de thoat che do ep.")
    asyncio.create_task(ticker())
    asyncio.create_task(console())
    async with server:
        await server.serve_forever()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        pass
