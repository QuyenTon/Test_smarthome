#include "proto.h"
#include "app_hooks.h"
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

proto_state_t g_state = { .gas_th = PROTO_GAS_TH_DEFAULT };

void proto_format_state(char *out, size_t n)
{
    snprintf(out, n, "STATE:L1=%d,L2=%d,FAN=%d,TH=%d,ALM=%d\n",
             g_state.l1, g_state.l2, g_state.fan, g_state.gas_th, g_state.alarm);
}

void proto_format_data(char *out, size_t n, float t, float h, int gas)
{
    snprintf(out, n, "DATA:T=%.1f,H=%.1f,GAS=%d\n", t, h, gas);
}

int proto_update_alarm(int gas, char *out, size_t n)
{
    int now = g_state.alarm;
    if (!now && gas >= g_state.gas_th) {
        now = 1;
    } else if (now && gas < g_state.gas_th - g_state.gas_th / 10) {   // trễ 10 %
        now = 0;
    }
    if (now == g_state.alarm) return 0;
    g_state.alarm = now;
    app_lcd_alarm(now, gas);
    snprintf(out, n, "ALARM:GAS=%d,VAL=%d\n", now, gas);
    return 1;
}

void proto_handle_line(const char *line, char *reply, size_t rn)
{
    char buf[64];
    reply[0] = 0;
    if (strlen(line) >= sizeof buf) { snprintf(reply, rn, "ERR:TOO_LONG\n"); return; }
    strcpy(buf, line);

    char *s = buf;
    while (isspace((unsigned char)*s)) s++;
    char *e = s + strlen(s);
    while (e > s && isspace((unsigned char)e[-1])) *--e = 0;
    if (*s == 0) return;                       // dòng trống: bỏ qua

    char *arg = strchr(s, ':');
    if (arg) *arg++ = 0;
    for (char *p = s; *p; p++) *p = (char)toupper((unsigned char)*p);

    int changed = 0;
    const char *err = NULL;

    if      (!strcmp(s, "L1_ON"))   { g_state.l1  = 1; app_set_light(1, 1); changed = 1; }
    else if (!strcmp(s, "L1_OFF"))  { g_state.l1  = 0; app_set_light(1, 0); changed = 1; }
    else if (!strcmp(s, "L2_ON"))   { g_state.l2  = 1; app_set_light(2, 1); changed = 1; }
    else if (!strcmp(s, "L2_OFF"))  { g_state.l2  = 0; app_set_light(2, 0); changed = 1; }
    else if (!strcmp(s, "FAN_ON"))  { g_state.fan = 1; app_set_fan(1);      changed = 1; }
    else if (!strcmp(s, "FAN_OFF")) { g_state.fan = 0; app_set_fan(0);      changed = 1; }
    else if (!strcmp(s, "MSG")) {
        while (arg && *arg == ' ') arg++;
        if (!arg || !*arg)                        err = "EMPTY";
        else if (strlen(arg) > PROTO_LCD_MSG_MAX) err = "TOO_LONG";
        else                                      app_lcd_message(arg);
    }
    else if (!strcmp(s, "SET_GAS_TH")) {
        char *end = NULL;
        long v = arg ? strtol(arg, &end, 10) : -1;
        if (!arg || !*arg || *end || v < 0 || v > 4095) err = "BAD_VALUE";
        else { g_state.gas_th = (int)v; changed = 1; }
    }
    else if (!strcmp(s, "GET_STATUS")) { proto_format_state(reply, rn); return; }
    else if (!strcmp(s, "PING"))       { snprintf(reply, rn, "PONG\n"); return; }
    else err = "UNKNOWN_CMD";

    if (err) { snprintf(reply, rn, "ERR:%s\n", err); return; }
    snprintf(reply, rn, "OK\n");
    if (changed) {
        size_t k = strlen(reply);
        proto_format_state(reply + k, rn - k);
    }
}
