#pragma once
#include "esp_err.h"

#define ETH_STATIC_IP    "192.168.50.2"
#define ETH_STATIC_GW    "192.168.50.1"
#define ETH_STATIC_MASK  "255.255.255.0"

// Khởi động Ethernet (LAN8720, RMII) với IP tĩnh. Gọi 1 lần ở đầu app_main.
esp_err_t eth_net_start(void);
