// Giả lập ngoại vi để thử Ethernet trên module WT32-ETH01 trơn (chưa có board).
// Khi ghép firmware của Quỳnh: bỏ file này khỏi main/CMakeLists.txt, viết lại các hàm trong app_hooks.h.
#include "app_hooks.h"
#include <math.h>
#include "esp_log.h"
#include "esp_random.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

static const char *TAG = "stub";

void app_set_light(int idx, int on) { ESP_LOGI(TAG, "Den %d -> %s", idx, on ? "BAT" : "TAT"); }
void app_set_fan(int on)            { ESP_LOGI(TAG, "Quat -> %s", on ? "BAT" : "TAT"); }
void app_lcd_message(const char *m) { ESP_LOGI(TAG, "LCD: %s", m); }
void app_lcd_alarm(int active, int gas)
{
    if (active) ESP_LOGW(TAG, "LCD: CANH BAO KHI GAS! (%d)", gas);
    else        ESP_LOGI(TAG, "LCD: het canh bao (%d)", gas);
}

// Khí gas dao động chậm (chu kỳ 90 s, 100..2700) để thấy báo động bật/tắt khi demo.
int app_read_sensors(float *t, float *h, int *gas)
{
    float s = (float)xTaskGetTickCount() / (float)configTICK_RATE_HZ;
    *t   = 28.0f + 2.0f * sinf(s / 40.0f) + ((int)(esp_random() % 11) - 5) * 0.05f;
    *h   = 65.0f + 5.0f * sinf(s / 55.0f) + ((int)(esp_random() % 11) - 5) * 0.10f;
    *gas = 1400 + (int)(1300.0f * sinf(s * 6.2831853f / 90.0f)) + (int)(esp_random() % 41) - 20;
    return 0;
}
