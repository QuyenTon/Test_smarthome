#pragma once
// Chạy 2 task: đọc cảm biến + kiểm tra báo động (luôn chạy), và TCP server cổng PROTO_PORT.
void tcp_server_start(void);
