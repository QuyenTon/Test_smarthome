#include "tcp_server.h"
#include "app_hooks.h"
#include "proto.h"
#include <errno.h>
#include <string.h>
#include "esp_log.h"
#include "freertos/FreeRTOS.h"
#include "freertos/queue.h"
#include "freertos/task.h"
#include "lwip/inet.h"
#include "lwip/sockets.h"

static const char *TAG = "tcp";

#define EVT_LEN 48
static QueueHandle_t s_evt_q;                 // các dòng ALARM chờ gửi cho client
static volatile float s_t, s_h;
static volatile int   s_gas, s_have;

// Đọc cảm biến và kiểm tra báo động kể cả khi chưa có client,
// để LCD vẫn báo cháy/khí gas khi dashboard tắt.
static void sensor_task(void *arg)
{
    char line[EVT_LEN];
    for (;;) {
        float t, h; int gas;
        if (app_read_sensors(&t, &h, &gas) == 0) {
            s_t = t; s_h = h; s_gas = gas; s_have = 1;
            if (proto_update_alarm(gas, line, sizeof line)) xQueueSend(s_evt_q, line, 0);
        }
        vTaskDelay(pdMS_TO_TICKS(PROTO_DATA_PERIOD_MS));
    }
}

static int send_str(int fd, const char *s)
{
    size_t len = strlen(s);
    while (len) {
        int n = send(fd, s, len, 0);
        if (n <= 0) return -1;
        s += n; len -= (size_t)n;
    }
    return 0;
}

static void serve_client(int fd)
{
    char rx[128], out[160], evt[EVT_LEN];
    size_t rxlen = 0;

    xQueueReset(s_evt_q);                      // bỏ các báo động cũ
    proto_format_state(out, sizeof out);
    if (send_str(fd, out) < 0) return;         // client mới biết ngay trạng thái hiện tại

    TickType_t next = xTaskGetTickCount();
    for (;;) {
        fd_set rfds;
        FD_ZERO(&rfds);
        FD_SET(fd, &rfds);
        struct timeval tv = { .tv_sec = 0, .tv_usec = 100 * 1000 };
        int r = select(fd + 1, &rfds, NULL, NULL, &tv);
        if (r < 0) return;

        if (r > 0) {
            int n = recv(fd, rx + rxlen, sizeof rx - rxlen - 1, 0);
            if (n <= 0) return;                // client đóng kết nối
            rxlen += (size_t)n;
            rx[rxlen] = 0;
            char *start = rx, *nl;
            while ((nl = strchr(start, '\n')) != NULL) {
                *nl = 0;
                proto_handle_line(start, out, sizeof out);
                if (out[0] && send_str(fd, out) < 0) return;
                start = nl + 1;
            }
            rxlen -= (size_t)(start - rx);
            memmove(rx, start, rxlen);
            if (rxlen >= sizeof rx - 1) rxlen = 0;   // dòng quá dài: bỏ
        }

        while (xQueueReceive(s_evt_q, evt, 0) == pdTRUE) {
            if (send_str(fd, evt) < 0) return;
        }

        if ((int32_t)(xTaskGetTickCount() - next) >= 0) {
            next += pdMS_TO_TICKS(PROTO_DATA_PERIOD_MS);
            if (s_have) {
                proto_format_data(out, sizeof out, s_t, s_h, s_gas);
                if (send_str(fd, out) < 0) return;
            }
        }
    }
}

static void server_task(void *arg)
{
    for (;;) {
        int ls = socket(AF_INET, SOCK_STREAM, IPPROTO_IP);
        if (ls < 0) { ESP_LOGE(TAG, "socket loi: %d", errno); vTaskDelay(pdMS_TO_TICKS(1000)); continue; }
        int one = 1;
        setsockopt(ls, SOL_SOCKET, SO_REUSEADDR, &one, sizeof one);
        struct sockaddr_in addr = {
            .sin_family = AF_INET,
            .sin_port = htons(PROTO_PORT),
            .sin_addr.s_addr = htonl(INADDR_ANY),
        };
        if (bind(ls, (struct sockaddr *)&addr, sizeof addr) != 0 || listen(ls, 1) != 0) {
            ESP_LOGE(TAG, "bind/listen loi: %d", errno);
            close(ls);
            vTaskDelay(pdMS_TO_TICKS(1000));
            continue;
        }
        ESP_LOGI(TAG, "TCP server dang cho o cong %d", PROTO_PORT);

        for (;;) {
            struct sockaddr_in src;
            socklen_t len = sizeof src;
            int fd = accept(ls, (struct sockaddr *)&src, &len);
            if (fd < 0) { vTaskDelay(pdMS_TO_TICKS(100)); continue; }
            ESP_LOGI(TAG, "Client ket noi: %s", inet_ntoa(src.sin_addr));

            setsockopt(fd, IPPROTO_TCP, TCP_NODELAY, &one, sizeof one);
            setsockopt(fd, SOL_SOCKET, SO_KEEPALIVE, &one, sizeof one);
            struct timeval sto = { .tv_sec = 2, .tv_usec = 0 };
            setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &sto, sizeof sto);

            serve_client(fd);
            shutdown(fd, SHUT_RDWR);
            close(fd);
            ESP_LOGI(TAG, "Client da ngat");
        }
    }
}

void tcp_server_start(void)
{
    s_evt_q = xQueueCreate(4, EVT_LEN);
    xTaskCreate(sensor_task, "sensor", 3072, NULL, 4, NULL);
    xTaskCreate(server_task, "tcp_srv", 4096, NULL, 5, NULL);
}
