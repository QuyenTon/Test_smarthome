// Giao thức Smart Room, xem PROTOCOL.md. File này không phụ thuộc ESP-IDF
// nên có thể biên dịch và thử trên máy tính (xem host_test/).
#pragma once
#include <stddef.h>

#define PROTO_PORT            3333
#define PROTO_DATA_PERIOD_MS  2000
#define PROTO_GAS_TH_DEFAULT  2000   // giá trị tạm, chỉnh sau khi đo MQ-2 thật
#define PROTO_LCD_MSG_MAX     32

typedef struct {
    int l1, l2, fan;
    int gas_th;   // ngưỡng, ADC thô 0..4095
    int alarm;    // 1 = đang báo khí gas
} proto_state_t;

extern proto_state_t g_state;

// Xử lý 1 dòng lệnh (không gồm '\n'). Ghi phản hồi (0..n dòng, mỗi dòng có '\n') vào reply.
void proto_handle_line(const char *line, char *reply, size_t reply_size);
void proto_format_state(char *out, size_t n);
void proto_format_data(char *out, size_t n, float temp_c, float hum_pct, int gas_raw);
// Gọi với mỗi mẫu gas mới. Trả 1 và ghi dòng ALARM vào out nếu trạng thái báo động vừa đổi.
int  proto_update_alarm(int gas_raw, char *out, size_t n);
