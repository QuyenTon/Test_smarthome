idf_component_register(SRCS "main.c" "eth_net.c" "tcp_server.c" "proto.c" "app_stub.c"
                       INCLUDE_DIRS "."
                       REQUIRES esp_eth esp_netif esp_event driver lwip)
