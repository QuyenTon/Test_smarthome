#include "esp_log.h"
#include "eth_net.h"
#include "tcp_server.h"

void app_main(void)
{
    ESP_LOGI("main", "Smart room - nut Ethernet (WT32-ETH01)");
    ESP_ERROR_CHECK(eth_net_start());
    tcp_server_start();
}
