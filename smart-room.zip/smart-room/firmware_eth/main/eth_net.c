// Ethernet cho WT32-ETH01: MAC trong ESP32 + PHY LAN8720 (RMII).
// Chân cố định của module (không dùng cho việc khác):
//   GPIO16 = bật dao động 50 MHz của LAN8720, GPIO0 = ngõ vào xung 50 MHz,
//   GPIO18 = MDIO, GPIO23 = MDC, GPIO19/21/22/25/26/27 = dữ liệu RMII.
// Viết cho ESP-IDF 5.x (đã tính khác biệt tên trường giữa 5.0-5.2 và 5.3+).
#include "eth_net.h"
#include "driver/gpio.h"
#include "esp_eth.h"
#include "esp_event.h"
#include "esp_idf_version.h"
#include "esp_log.h"
#include "esp_netif.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#define PIN_PHY_POWER  16
#define PIN_MDC        23
#define PIN_MDIO       18
#define PHY_ADDR       1

static const char *TAG = "eth";

static void eth_event_handler(void *arg, esp_event_base_t base, int32_t id, void *data)
{
    switch (id) {
    case ETHERNET_EVENT_CONNECTED:    ESP_LOGI(TAG, "Day mang da cam (link up)"); break;
    case ETHERNET_EVENT_DISCONNECTED: ESP_LOGW(TAG, "Mat link (link down)");     break;
    case ETHERNET_EVENT_START:        ESP_LOGI(TAG, "Ethernet start");           break;
    case ETHERNET_EVENT_STOP:         ESP_LOGI(TAG, "Ethernet stop");            break;
    default: break;
    }
}

esp_err_t eth_net_start(void)
{
    // 1. Bật dao động 50 MHz. Phải làm trước khi khởi tạo EMAC.
    gpio_config_t io = {
        .pin_bit_mask = 1ULL << PIN_PHY_POWER,
        .mode = GPIO_MODE_OUTPUT,
    };
    ESP_ERROR_CHECK(gpio_config(&io));
    gpio_set_level(PIN_PHY_POWER, 0);
    vTaskDelay(pdMS_TO_TICKS(10));
    gpio_set_level(PIN_PHY_POWER, 1);
    vTaskDelay(pdMS_TO_TICKS(100));

    // 2. Mạng + sự kiện
    ESP_ERROR_CHECK(esp_netif_init());
    ESP_ERROR_CHECK(esp_event_loop_create_default());
    esp_netif_config_t netif_cfg = ESP_NETIF_DEFAULT_ETH();
    esp_netif_t *netif = esp_netif_new(&netif_cfg);

    // 3. MAC (trong ESP32) + PHY (LAN8720)
    eth_mac_config_t mac_cfg = ETH_MAC_DEFAULT_CONFIG();
    eth_esp32_emac_config_t emac_cfg = ETH_ESP32_EMAC_DEFAULT_CONFIG();
#if ESP_IDF_VERSION >= ESP_IDF_VERSION_VAL(5, 3, 0)
    emac_cfg.smi_gpio.mdc_num  = PIN_MDC;
    emac_cfg.smi_gpio.mdio_num = PIN_MDIO;
#else
    emac_cfg.smi_mdc_gpio_num  = PIN_MDC;
    emac_cfg.smi_mdio_gpio_num = PIN_MDIO;
#endif
    emac_cfg.clock_config.rmii.clock_mode = EMAC_CLK_EXT_IN;  // xung 50 MHz từ LAN8720
    emac_cfg.clock_config.rmii.clock_gpio = 0;                // vào chân GPIO0
    esp_eth_mac_t *mac = esp_eth_mac_new_esp32(&emac_cfg, &mac_cfg);

    eth_phy_config_t phy_cfg = ETH_PHY_DEFAULT_CONFIG();
    phy_cfg.phy_addr = PHY_ADDR;
    phy_cfg.reset_gpio_num = -1;   // WT32-ETH01 không có chân reset PHY; mặc định của IDF là GPIO5, KHÔNG dùng
    esp_eth_phy_t *phy = esp_eth_phy_new_lan87xx(&phy_cfg);

    esp_eth_config_t eth_cfg = ETH_DEFAULT_CONFIG(mac, phy);
    esp_eth_handle_t eth = NULL;
    ESP_ERROR_CHECK(esp_eth_driver_install(&eth_cfg, &eth));
    ESP_ERROR_CHECK(esp_netif_attach(netif, esp_eth_new_netif_glue(eth)));

    // 4. IP tĩnh
    esp_err_t r = esp_netif_dhcpc_stop(netif);
    if (r != ESP_OK && r != ESP_ERR_ESP_NETIF_DHCP_ALREADY_STOPPED) {
        ESP_LOGW(TAG, "Khong tat duoc DHCP client: %s", esp_err_to_name(r));
    }
    esp_netif_ip_info_t ip = { 0 };
    ip.ip.addr      = esp_ip4addr_aton(ETH_STATIC_IP);
    ip.gw.addr      = esp_ip4addr_aton(ETH_STATIC_GW);
    ip.netmask.addr = esp_ip4addr_aton(ETH_STATIC_MASK);
    ESP_ERROR_CHECK(esp_netif_set_ip_info(netif, &ip));

    ESP_ERROR_CHECK(esp_event_handler_register(ETH_EVENT, ESP_EVENT_ANY_ID, &eth_event_handler, NULL));
    ESP_ERROR_CHECK(esp_eth_start(eth));
    ESP_LOGI(TAG, "IP tinh: %s", ETH_STATIC_IP);
    return ESP_OK;
}
