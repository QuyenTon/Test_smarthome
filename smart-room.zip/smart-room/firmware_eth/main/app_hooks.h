// Các "móc" nối giữa lớp mạng và phần ngoại vi.
// app_stub.c đang giả lập để thử Ethernet trên module trơn.
// Khi ghép với firmware của Quỳnh: bỏ app_stub.c khỏi main/CMakeLists.txt
// và viết lại 5 hàm này gọi sang bsp_* thật (đèn, quạt, LCD, DHT11, MQ-2).
#pragma once

void app_set_light(int idx, int on);   // idx = 1 hoặc 2
void app_set_fan(int on);
void app_lcd_message(const char *msg); // dòng chữ từ dashboard, ASCII, <= 32 ký tự
void app_lcd_alarm(int active, int gas_raw); // báo / hết báo khí gas lên LCD (và buzzer nếu muốn)
int  app_read_sensors(float *temp_c, float *hum_pct, int *gas_raw); // trả 0 nếu đọc OK
