// Thử bộ phân tích giao thức trên máy tính (không cần ESP32):
//   gcc -I../main test_proto.c ../main/proto.c -o test_proto && ./test_proto
#include "proto.h"
#include "app_hooks.h"
#include <stdio.h>
#include <string.h>

static int fails;
static char last_msg[64];
static int last_alarm = -1;

void app_set_light(int i, int on) { (void)i; (void)on; }
void app_set_fan(int on) { (void)on; }
void app_lcd_message(const char *m) { strncpy(last_msg, m, sizeof last_msg - 1); }
void app_lcd_alarm(int a, int g) { (void)g; last_alarm = a; }
int  app_read_sensors(float *t, float *h, int *g) { *t = *h = 0; *g = 0; return 0; }

static void expect(const char *in, const char *want)
{
    char out[160];
    proto_handle_line(in, out, sizeof out);
    int ok = strcmp(out, want) == 0;
    if (!ok) fails++;
    printf("%s  %-22s -> %s", ok ? "ok  " : "FAIL", in, out[0] ? out : "(khong tra loi)\n");
    if (!ok) printf("      mong doi: %s", want[0] ? want : "(khong tra loi)\n");
}

int main(void)
{
    expect("L1_ON",              "OK\nSTATE:L1=1,L2=0,FAN=0,TH=2000,ALM=0\n");
    expect("fan_on\r",           "OK\nSTATE:L1=1,L2=0,FAN=1,TH=2000,ALM=0\n");
    expect("  L1_OFF  ",         "OK\nSTATE:L1=0,L2=0,FAN=1,TH=2000,ALM=0\n");
    expect("MSG:Xin Chao",       "OK\n");
    expect("MSG:",               "ERR:EMPTY\n");
    expect("MSG:123456789012345678901234567890123", "ERR:TOO_LONG\n");
    expect("SET_GAS_TH:1500",    "OK\nSTATE:L1=0,L2=0,FAN=1,TH=1500,ALM=0\n");
    expect("SET_GAS_TH:9999",    "ERR:BAD_VALUE\n");
    expect("SET_GAS_TH:abc",     "ERR:BAD_VALUE\n");
    expect("GET_STATUS",         "STATE:L1=0,L2=0,FAN=1,TH=1500,ALM=0\n");
    expect("PING",               "PONG\n");
    expect("HELLO",              "ERR:UNKNOWN_CMD\n");
    expect("",                   "");

    if (strcmp(last_msg, "Xin Chao")) { puts("FAIL  noi dung MSG bi doi"); fails++; }

    char a[64];
    int r1 = proto_update_alarm(1400, a, sizeof a);   // dưới ngưỡng 1500
    int r2 = proto_update_alarm(1600, a, sizeof a);   // vượt
    int r3 = proto_update_alarm(1700, a, sizeof a);   // vẫn vượt, không báo lại
    int r4 = proto_update_alarm(1400, a, sizeof a);   // 1400 >= 1350 nên chưa hết báo
    int r5 = proto_update_alarm(1300, a, sizeof a);   // < 1350 nên hết báo
    printf("alarm: %d %d %d %d %d (mong doi 0 1 0 0 1), dong cuoi: %s", r1, r2, r3, r4, r5, a);
    if (r1 != 0 || r2 != 1 || r3 != 0 || r4 != 0 || r5 != 1 || last_alarm != 0) fails++;

    puts(fails ? "CO LOI" : "TAT CA DAT");
    return fails != 0;
}
